import React from "react";
import { Navigation, Pagination, Scrollbar, A11y } from "swiper/modules";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import "swiper/css/scrollbar";

const Categories = () => {
  return (
    <>
      <div className="bg-gray-50 w-full h-full p-5">
        <Swiper
          modules={[Navigation, Pagination, Scrollbar, A11y]}
          spaceBetween={8}
          slidesPerView={8} // Default value for large screens
          breakpoints={{
            1024: {
              // For screens larger than 1024px (desktop)
              slidesPerView: 8,
            },
            768: {
              // For screens between 768px and 1024px (tablets)
              slidesPerView: 4,
            },
            480: {
              // For screens smaller than 768px (mobile)
              slidesPerView: 2,
            },
          }}
          onSwiper={(swiper) => console.log(swiper)}
          onSlideChange={() => console.log("slide change")}
        >
          <SwiperSlide>
            <li className="font-Poppins text-sm font-medium">Web Development</li>
          </SwiperSlide>
          
          <SwiperSlide>
            <li className="font-Poppins text-sm font-medium">Data Analytics</li>
          </SwiperSlide>
          <SwiperSlide>
            <li className="font-Poppins text-sm font-medium">Product Design</li>
          </SwiperSlide>
          <SwiperSlide>
            <li className="font-Poppins text-sm font-medium">Web Development</li>
          </SwiperSlide>
          
          <SwiperSlide>
            <li className="font-Poppins text-sm font-medium">Data Analytics</li>
          </SwiperSlide>
          <SwiperSlide>
            <li className="font-Poppins text-sm font-medium">Product Design</li>
          </SwiperSlide>
          <SwiperSlide>
            <li className="font-Poppins text-sm font-medium">Web Development</li>
          </SwiperSlide>
          
          <SwiperSlide>
            <li className="font-Poppins text-sm font-medium">Data Analytics</li>
          </SwiperSlide>
          <SwiperSlide>
            <li className="font-Poppins text-sm font-medium">Product Design</li>
          </SwiperSlide>
          <SwiperSlide>
            <li className="font-Poppins text-sm font-medium">Web Development</li>
          </SwiperSlide>
          
          <SwiperSlide>
            <li className="font-Poppins text-sm font-medium">Data Analytics</li>
          </SwiperSlide>
          <SwiperSlide>
            <li className="font-Poppins text-sm font-medium">Product Design</li>
          </SwiperSlide>
        </Swiper>
      </div>
    </>
  );
};

export default Categories;
