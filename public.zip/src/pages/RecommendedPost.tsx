import React, { useState, useEffect } from "react";
import axios from "axios";
import PostCardFive from "../components/PostCardFive";
import { Link } from "react-router-dom";

const RecommendedPost = () => {
  const [recommendedPost, setRecommendedPost] = useState<any>([]);

  useEffect(() => {
    const fetchRecommendedPosts = async () => {
      try {
        const { data } = await axios.get(
          "http://localhost:5000/api/blog-posts/recommendedPost"
        );
        setRecommendedPost(data);
      } catch (error) {
        console.log("Error fetching recommended posts:", error);
      }
    };
    fetchRecommendedPosts();
  }, []);

  return (
    <div className="p-5 space-y-4">
      <h1 className="text-xl font-semibold font-Roboto">
        Recommended Posts
      </h1>

      <div className="grid grid-cols-4 gap-2 bg-gray-100 p-5">
        {recommendedPost.map((post, index) => (
          <Link to = {`singleBlogPage/${post._id}`}>
          <PostCardFive key={post._id} post={post} />
          </Link>
        ))}
      </div>
    </div>
  );
};

export default RecommendedPost;
