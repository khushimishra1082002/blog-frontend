import React from 'react'

const TopCategories = () => {
  return (
    <>
      <div>
        Top categories
      </div>
    </>
  )
}

export default TopCategories
