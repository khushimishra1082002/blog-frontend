import React,{useState} from 'react'
import Login from './Login';
import Register from './Register';

const LoggedInPage = () => {
   const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);
  return (
    <>
      <div className='grid grid-cols-2 h-screen '>
      <div className='w-full h-full'>
        <img className='w-full h-full object-cover'
         src='https://cusmin.com/images/blog/how-to-add-wordpress-login-background-image/wordpress-login-bg-image-1280.webp'/>
      </div>
      <div className='flex flex-col justify-center w-8/12 m-auto space-y-5 '>
    
    <div className="h-full ">
        {isLoggedIn ? (
          <Register setIsLoggedIn={setIsLoggedIn} />
        ) : (
          <Login setIsLoggedIn={setIsLoggedIn} />
        )}
      </div>
      </div>
      
      </div>
    </>
  )
}

export default LoggedInPage
