import React from 'react'

const SearchResults = () => {
  return (
    <>
      <div>
        SearchResults
      </div>
    </>
  )
}

export default SearchResults
