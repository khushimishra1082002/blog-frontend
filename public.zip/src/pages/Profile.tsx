import React from "react";
import Header from "../components/Header";
import { FaRegThumbsUp, FaThumbsUp } from "react-icons/fa6";
import { LuMessageCircleMore } from "react-icons/lu";

const Profile = () => {
  return (
    <>
      <div className="sticky top-0 left-0 w-full z-50 bg-white shadow-md">
        <Header />
      </div>

      <div className=" relative h-96 w-full ">
        <img
          className=" w-full h-full object-cover"
          src="https://images.unsplash.com/photo-1575936123452-b67c3203c357?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8fDA%3D"
        />
        <div className="w-16 h-16 rounded-full absolute -bottom-7 left-14">
          <img
            className=" w-full h-full rounded-full"
            src="https://d2gwgwt9a7yxle.cloudfront.net/what_is_user_id_in_net_banking_mobile_871b681e52.jpg"
          />
        </div>

        <div className=" pt-12 grid grid-cols-3 w-11/12 m-auto gap-16">
          <div className=" flex flex-col gap-1 ">
            <h4 className=" font-RobotoFlex text-xl font-medium">
              My name Ravii sharmaa
            </h4>
            <span
              className=" font-OpenSans text-[13px] font-medium text-cyan-500
          "
            >
              RaviiSharmaa@gmail.com
            </span>
            <p className=" font-Inter font-light text-[12px]">
              Look again at that dot.That home that us.There are more online
              learning platforms available than ever. Let's talk about how to
              choose one, and the best 13 options.
            </p>
            <div className=" grid grid-cols-2 border border-black/10 my-4">
              <div className="border border-black/10 flex flex-col justify-center  p-6">
                <h4 className=" text-lg font-semibold font-Roboto">13.5k </h4>
                <span className=" font-Roboto text-gray-500 text-sm">
                  Followers
                </span>
              </div>
              <div className="border border-black/10 flex flex-col justify-center  p-6">
                <h4 className=" text-lg font-medium font-Roboto">345</h4>
                <span className=" font-Roboto text-gray-500 text-sm">
                  Posts
                </span>
              </div>
              <div className="border border-black/10 flex flex-col justify-center  p-6">
                <h4 className=" text-lg font-medium font-Roboto">43</h4>
                <span className=" font-Roboto text-gray-500 text-sm">
                  Collections
                </span>
              </div>
              <div className="border border-black/10 flex flex-col justify-center  p-6">
                <h4 className=" text-lg font-medium font-Roboto">
                  11.2k likes
                </h4>
                <span className=" font-Roboto text-gray-500 text-sm">
                  Collections
                </span>
              </div>
            </div>
          </div>
          <div className=" col-span-2 space-y-5 py-7">
            <div className="flex justify-between items-center space-y-6">
              <div className="flex gap-4">
                <div>
                  <span
                    className=" border border-black/10 p-1 text-sm text-gray-800 font-Poppins
            font-medium"
                  >
                    Post
                  </span>
                  <span className="border border-black/10 p-1 text-sm text-gray-800 font-Poppins">
                    134
                  </span>
                </div>
                <div>
                  <span
                    className=" border border-black/10 p-1 text-sm text-gray-800 font-Poppins
             font-medium"
                  >
                    Photos
                  </span>
                  <span className="border border-black/10 p-1 text-sm text-gray-500 font-Poppins">
                    45
                  </span>
                </div>
                <div>
                  <span
                    className=" border border-black/10 p-1 text-sm text-gray-800 font-Poppins
             font-medium"
                  >
                    Likes
                  </span>
                  <span className="border border-black/10 p-1 text-sm text-gray-800 font-Poppins">
                    45
                  </span>
                </div>
              </div>
              <div>
                <button
                  className="bg-gray-950 text-white font-Inter
          rounded-sm hover:scale-105 duration-500 text-sm p-2"
                >
                  Message
                </button>
              </div>
            </div>
            <div className=" w-full h-[1px] bg-gray-300"></div>
            <div className="grid grid-cols-2 gap-7 gap-y-8">
              <div className=" space-y-4">
                <div className="w-full h-60 rounded-md">
                  <img
                    className=" w-full h-full rounded-xl"
                    src="https://th.bing.com/th/id/OIP.hld-ERmS7BrU2it892qMuAHaEo?rs=1&pid=ImgDetMain"
                  />
                </div>
                <div className=" grid grid-cols-2 justify-between ">
                  <div className="flex gap-2 items-center">
                    <div className="w-6 h-6 rounded-full">
                      <img
                        className=" w-full h-full rounded-full"
                        src="https://d2gwgwt9a7yxle.cloudfront.net/what_is_user_id_in_net_banking_mobile_871b681e52.jpg"
                      />
                    </div>
                    <span className=" font-Roboto text-sm ">Rahul</span>
                  </div>
                  <div className=" flex gap-4 justify-end">
                    <div className=" flex items-center gap-1 text-gray-500 text-[14px]">
                      <FaThumbsUp />
                      <span>34</span>
                    </div>
                    <div className=" flex items-center gap-1 text-gray-500 text-[14px]">
                      <LuMessageCircleMore />
                      <span>34</span>
                    </div>
                  </div>
                  <div></div>
                </div>
              </div>
              <div className=" space-y-4">
                <div className="w-full h-60 rounded-md">
                  <img
                    className=" w-full h-full rounded-xl"
                    src="https://th.bing.com/th/id/OIP.mhL_1bmQECybgQToyUOfNwHaFB?w=620&h=420&rs=1&pid=ImgDetMain"
                  />
                </div>
                <div className=" grid grid-cols-2 justify-between ">
                  <div className="flex gap-2 items-center">
                    <div className="w-6 h-6 rounded-full">
                      <img
                        className=" w-full h-full rounded-full"
                        src="https://d2gwgwt9a7yxle.cloudfront.net/what_is_user_id_in_net_banking_mobile_871b681e52.jpg"
                      />
                    </div>
                    <span className=" font-Roboto text-sm ">Rahul</span>
                  </div>
                  <div className=" flex gap-4 justify-end">
                    <div className=" flex items-center gap-1 text-gray-500 text-[14px]">
                      <FaThumbsUp />
                      <span>34</span>
                    </div>
                    <div className=" flex items-center gap-1 text-gray-500 text-[14px]">
                      <LuMessageCircleMore />
                      <span>34</span>
                    </div>
                  </div>
                  <div></div>
                </div>
              </div>
              <div className=" space-y-4">
                <div className="w-full h-60 rounded-md">
                  <img
                    className=" w-full h-full rounded-xl"
                    src="https://th.bing.com/th/id/OIP.flN53tFuJyVxpUHVfuM-nQHaE7?w=626&h=417&rs=1&pid=ImgDetMain"
                  />
                </div>
                <div className=" grid grid-cols-2 justify-between ">
                  <div className="flex gap-2 items-center">
                    <div className="w-6 h-6 rounded-full">
                      <img
                        className=" w-full h-full rounded-full"
                        src="https://d2gwgwt9a7yxle.cloudfront.net/what_is_user_id_in_net_banking_mobile_871b681e52.jpg"
                      />
                    </div>
                    <span className=" font-Roboto text-sm ">Rahul</span>
                  </div>
                  <div className=" flex gap-4 justify-end">
                    <div className=" flex items-center gap-1 text-gray-500 text-[14px]">
                      <FaThumbsUp />
                      <span>34</span>
                    </div>
                    <div className=" flex items-center gap-1 text-gray-500 text-[14px]">
                      <LuMessageCircleMore />
                      <span>34</span>
                    </div>
                  </div>
                  <div></div>
                </div>
              </div>
              <div className=" space-y-4">
                <div className="w-full h-60 rounded-md">
                  <img
                    className=" w-full h-full rounded-xl"
                    src="https://img.freepik.com/free-photo/landscape-morning-fog-mountains-with-hot-air-balloons-sunrise_335224-794.jpg?t=st=1743662630~exp=1743666230~hmac=de6fcf80c7ab0523fc4b60fcd9bdbdb5739973095d98ada9bee1883d31133786&w=1380"
                  />
                </div>
                <div className=" grid grid-cols-2 justify-between ">
                  <div className="flex gap-2 items-center">
                    <div className="w-6 h-6 rounded-full">
                      <img
                        className=" w-full h-full rounded-full"
                        src="https://d2gwgwt9a7yxle.cloudfront.net/what_is_user_id_in_net_banking_mobile_871b681e52.jpg"
                      />
                    </div>
                    <span className=" font-Roboto text-sm ">Rahul</span>
                  </div>
                  <div className=" flex gap-4 justify-end">
                    <div className=" flex items-center gap-1 text-gray-500 text-[14px]">
                      <FaThumbsUp />
                      <span>34</span>
                    </div>
                    <div className=" flex items-center gap-1 text-gray-500 text-[14px]">
                      <LuMessageCircleMore />
                      <span>34</span>
                    </div>
                  </div>
                  <div></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Profile;
