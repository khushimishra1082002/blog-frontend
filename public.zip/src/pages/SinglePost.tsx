import React, { useState, useEffect } from "react";
import Header from "../components/Header";
import { FaThumbsUp } from "react-icons/fa6";
import { LuMessageCircleMore } from "react-icons/lu";
import SimilorPost from "./SimilorPost";
import { useParams } from "react-router-dom";
import axios from "axios";
import Categories from "./Categories";
import Comment from "../pages/Comment";

const SinglePost = () => {
  const { id } = useParams();

  console.log("id", id);

  const [singlePosts, setSinglePosts] = useState<any>(null);

  useEffect(() => {
    const fetchSinglePosts = async () => {
      try {
        const { data } = await axios.get(
          `http://localhost:5000/api/blog-posts/singlePost/${id}`
        );
        setSinglePosts(data);
      } catch (error) {
        console.log("Error fetching single posts:", error);
      }
    };
    fetchSinglePosts();
  }, [id]);

  return (
    <>
      <div className="sticky top-0 left-0 w-full z-50 bg-white shadow">
        <Header />
        <Categories />
      </div>

      <div className=" grid grid-cols-2 gap-8 p-5 place-content-center py-7">
        <div className=" w-full h-full">
          <img
            className=" w-full h-full rounded shadow-lg"
            src={singlePosts?.image}
          />
        </div>
        <div className=" space-y-5 py-3">
          <h2 className="font-Inter text-2xl font-medium">
            {singlePosts?.title}
          </h2>
          <div className="space-x-2">
            <span
              className=" text-base text-gray-500 font-Roboto font-medium
                "
            >
              March 20 2025
            </span>
          </div>
          <p className="font-Inter font-light text-sm">
            {singlePosts?.content}
          </p>
          <div className=" flex justify-between">
            <div className=" flex gap-2 items-center">
              <div className=" w-10 h-10 rounded-full">
                <img
                  className=" w-full h-full rounded-full"
                  src="https://d2gwgwt9a7yxle.cloudfront.net/what_is_user_id_in_net_banking_mobile_871b681e52.jpg"
                />
              </div>
              <div className=" flex flex-col">
                <h4 className=" font-RobotoFlex text-base font-medium">
                  {singlePosts?.author.name}
                </h4>
                <span
                  className=" font-OpenSans text-[12px] font-medium text-cyan-500
          "
                >
                  {singlePosts?.author.email}
                </span>
              </div>
            </div>
            <div className=" flex gap-4 justify-end">
              <div className=" flex items-center gap-1 text-gray-500 text-[14px]">
                <FaThumbsUp />
                <span>34</span>
              </div>
              <div className=" flex items-center gap-1 text-gray-500 text-[14px]">
                <LuMessageCircleMore />
                <span>34</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Comment postId = {id} />
      <SimilorPost id={id} />
    </>
  );
};

export default SinglePost;
