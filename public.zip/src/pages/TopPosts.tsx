import React, { useState, useEffect } from "react";
import axios from "axios";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination } from "swiper/modules";
import "swiper/css";
import "swiper/css/pagination";
import { Link } from "react-router-dom";

const TopPosts = () => {
  const [topPost, setTopPost] = useState<any>([]);

  useEffect(() => {
    const fetchTopPosts = async () => {
      try {
        const { data } = await axios.get(
          "http://localhost:5000/api/blog-posts/topPosts"
        );
        setTopPost(data);
      } catch (error) {
        console.log("Error fetching top posts:", error);
      }
    };
    fetchTopPosts();
  }, []);

  return (
    <div className="bg-white p-5 space-y-4">
      <h1 className="text-xl font-semibold font-Roboto">Top Posts</h1>

      <div className="relative h-96">
        <Swiper
          className="h-full"
          modules={[Autoplay, Pagination]}
          slidesPerView={1}
          spaceBetween={10}
          autoplay={{
            delay: 3000,
            disableOnInteraction: false,
          }}
          breakpoints={{
            640: { slidesPerView: 1 },
            768: { slidesPerView: 2 },
            1024: { slidesPerView: 3 },
            1280: { slidesPerView: 4 },
          }}
        >
          {topPost.map((item) => (
            <SwiperSlide key={item._id} className="h-full">
             <Link to = {`singleBlogPage/${item._id}`}>
             <div
                className="bg-white border border-black/10 rounded
               shadow-lg hover:shadow-xl hover:scale-105 duration-500 p-5 space-y-4 h-full"
              >
                <div className="flex gap-2 items-center">
                  <div className="w-6 h-6 rounded-full">
                    <img
                      className="w-full h-full rounded-full"
                      src="https://d2gwgwt9a7yxle.cloudfront.net/what_is_user_id_in_net_banking_mobile_871b681e52.jpg"
                      alt="user avatar"
                    />
                  </div>
                  <span className="font-Roboto text-sm">
                    {item.author?.name}
                  </span>
                </div>

                <h4 className="font-Inter text-sm font-medium line-clamp-2
                hover:underline">
                  {item.title}
                </h4>

                <div className="w-full h-64 overflow-hidden">
                  <img
                    className="w-full h-full shadow-lg object-cover
                   transition-transform duration-300 ease-in-out hover:scale-110"
                    src={item.image}
                    alt={item.title}
                  />
                </div>
              </div>
             </Link>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </div>
  );
};

export default TopPosts;
