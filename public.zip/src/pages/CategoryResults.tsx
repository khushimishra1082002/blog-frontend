import React from "react";
import Header from "../components/Header";
import { Navigation, Pagination, Scrollbar, A11y } from "swiper/modules";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import "swiper/css/scrollbar";
import { FaThumbsUp, FaThumbsDown } from "react-icons/fa6";
import { LuMessageCircleMore } from "react-icons/lu";
import { IoIosSearch } from "react-icons/io";
import { LuFileSpreadsheet } from "react-icons/lu";
import { FaReply } from "react-icons/fa";

const CategoryResults = () => {
  return (
    <>
      <div className="sticky top-0 left-0 w-full z-50 bg-white shadow">
        <Header />
      </div>
      <div className=" p-6 space-y-8">
        <div className=" flex justify-between items-center ">
          <div className=" ">
            <span className=" text-xl font-Roboto font-medium ">
              Nature Blog
            </span>
          </div>
          <div className="flex gap-2 items-center">
            <IoIosSearch className=" text-gray-800 text-xl" />
            <input
              type="text"
              className=" p-2 w-96 border  border-black/15 rounded-md font-Lato"
              placeholder="Search Blog"
            />
          </div>
        </div>

        <div className="">
          <Swiper
            modules={[Navigation, Pagination, Scrollbar, A11y]}
            spaceBetween={6}
            slidesPerView={4}
            onSwiper={(swiper) => console.log(swiper)}
            onSlideChange={() => console.log("slide change")}
            className=" bg-gray-100 "
          >
            <SwiperSlide
              className=" bg-white p-4 border border-black/15
                  rounded-md"
            >
              <div className=" space-y-4">
                <div className="w-full h-60 rounded-md">
                  <img
                    className=" w-full h-full rounded-xl"
                    src="https://fsa2-assets.imgix.net/assets/laptop-coding-terminal.jpg?auto=compress%2Cformat&crop=focalpoint&domain=fsa2-assets.imgix.net&fit=crop&fp-x=0.5&fp-y=0.5&h=558&ixlib=php-3.3.0&w=992"
                  />
                </div>
                <h2 className=" font-medium font-RobotoFlex text-sm">
                  Meet The Mentors : How I Find My Way into Coding
                </h2>
                <div className=" grid grid-cols-2 justify-between ">
                  <div className="flex gap-2 items-center">
                    <div className="w-6 h-6 rounded-full">
                      <img
                        className=" w-full h-full rounded-full"
                        src="https://d2gwgwt9a7yxle.cloudfront.net/what_is_user_id_in_net_banking_mobile_871b681e52.jpg"
                      />
                    </div>
                    <span className=" font-Roboto text-sm ">Rahul</span>
                  </div>
                  <div className=" flex gap-4 justify-end">
                    <div className=" flex items-center gap-1 text-gray-500 text-[14px]">
                      <FaThumbsUp />
                      <span>34</span>
                    </div>
                    <div className=" flex items-center gap-1 text-gray-500 text-[14px]">
                      <LuMessageCircleMore />
                      <span>34</span>
                    </div>
                  </div>
                  <div></div>
                </div>
              </div>
            </SwiperSlide>
            <SwiperSlide
              className=" bg-white p-4 border border-black/15
                  rounded-md"
            >
              <div className=" space-y-4">
                <div className="w-full h-60 rounded-md">
                  <img
                    className=" w-full h-full rounded-xl"
                    src="https://fsa2-assets.imgix.net/assets/laptop-coding-terminal.jpg?auto=compress%2Cformat&crop=focalpoint&domain=fsa2-assets.imgix.net&fit=crop&fp-x=0.5&fp-y=0.5&h=558&ixlib=php-3.3.0&w=992"
                  />
                </div>
                <h2 className=" font-medium font-RobotoFlex text-sm">
                  Meet The Mentors : How I Find My Way into Coding
                </h2>
                <div className=" grid grid-cols-2 justify-between ">
                  <div className="flex gap-2 items-center">
                    <div className="w-6 h-6 rounded-full">
                      <img
                        className=" w-full h-full rounded-full"
                        src="https://d2gwgwt9a7yxle.cloudfront.net/what_is_user_id_in_net_banking_mobile_871b681e52.jpg"
                      />
                    </div>
                    <span className=" font-Roboto text-sm ">Rahul</span>
                  </div>
                  <div className=" flex gap-4 justify-end">
                    <div className=" flex items-center gap-1 text-gray-500 text-[14px]">
                      <FaThumbsUp />
                      <span>34</span>
                    </div>
                    <div className=" flex items-center gap-1 text-gray-500 text-[14px]">
                      <LuMessageCircleMore />
                      <span>34</span>
                    </div>
                  </div>
                  <div></div>
                </div>
              </div>
            </SwiperSlide>
            <SwiperSlide
              className=" bg-white p-4 border border-black/15
                  rounded-md"
            >
              <div className=" space-y-4">
                <div className="w-full h-60 rounded-md">
                  <img
                    className=" w-full h-full rounded-xl"
                    src="https://fsa2-assets.imgix.net/assets/laptop-coding-terminal.jpg?auto=compress%2Cformat&crop=focalpoint&domain=fsa2-assets.imgix.net&fit=crop&fp-x=0.5&fp-y=0.5&h=558&ixlib=php-3.3.0&w=992"
                  />
                </div>
                <h2 className=" font-medium font-RobotoFlex text-sm">
                  Meet The Mentors : How I Find My Way into Coding
                </h2>
                <div className=" grid grid-cols-2 justify-between ">
                  <div className="flex gap-2 items-center">
                    <div className="w-6 h-6 rounded-full">
                      <img
                        className=" w-full h-full rounded-full"
                        src="https://d2gwgwt9a7yxle.cloudfront.net/what_is_user_id_in_net_banking_mobile_871b681e52.jpg"
                      />
                    </div>
                    <span className=" font-Roboto text-sm ">Rahul</span>
                  </div>
                  <div className=" flex gap-4 justify-end">
                    <div className=" flex items-center gap-1 text-gray-500 text-[14px]">
                      <FaThumbsUp />
                      <span>34</span>
                    </div>
                    <div className=" flex items-center gap-1 text-gray-500 text-[14px]">
                      <LuMessageCircleMore />
                      <span>34</span>
                    </div>
                  </div>
                  <div></div>
                </div>
              </div>
            </SwiperSlide>
            <SwiperSlide
              className=" bg-white p-4 border border-black/15
                  rounded-md"
            >
              <div className=" space-y-4">
                <div className="w-full h-60 rounded-md">
                  <img
                    className=" w-full h-full rounded-xl"
                    src="https://fsa2-assets.imgix.net/assets/laptop-coding-terminal.jpg?auto=compress%2Cformat&crop=focalpoint&domain=fsa2-assets.imgix.net&fit=crop&fp-x=0.5&fp-y=0.5&h=558&ixlib=php-3.3.0&w=992"
                  />
                </div>
                <h2 className=" font-medium font-RobotoFlex text-sm">
                  Meet The Mentors : How I Find My Way into Coding
                </h2>
                <div className=" grid grid-cols-2 justify-between ">
                  <div className="flex gap-2 items-center">
                    <div className="w-6 h-6 rounded-full">
                      <img
                        className=" w-full h-full rounded-full"
                        src="https://d2gwgwt9a7yxle.cloudfront.net/what_is_user_id_in_net_banking_mobile_871b681e52.jpg"
                      />
                    </div>
                    <span className=" font-Roboto text-sm ">Rahul</span>
                  </div>
                  <div className=" flex gap-4 justify-end">
                    <div className=" flex items-center gap-1 text-gray-500 text-[14px]">
                      <FaThumbsUp />
                      <span>34</span>
                    </div>
                    <div className=" flex items-center gap-1 text-gray-500 text-[14px]">
                      <LuMessageCircleMore />
                      <span>34</span>
                    </div>
                  </div>
                  <div></div>
                </div>
              </div>
            </SwiperSlide>
            <SwiperSlide
              className=" bg-white p-4 border border-black/15
                  rounded-md"
            >
              <div className=" space-y-4">
                <div className="w-full h-60 rounded-md">
                  <img
                    className=" w-full h-full rounded-xl"
                    src="https://fsa2-assets.imgix.net/assets/laptop-coding-terminal.jpg?auto=compress%2Cformat&crop=focalpoint&domain=fsa2-assets.imgix.net&fit=crop&fp-x=0.5&fp-y=0.5&h=558&ixlib=php-3.3.0&w=992"
                  />
                </div>
                <h2 className=" font-medium font-RobotoFlex text-sm">
                  Meet The Mentors : How I Find My Way into Coding
                </h2>
                <div className=" grid grid-cols-2 justify-between ">
                  <div className="flex gap-2 items-center">
                    <div className="w-6 h-6 rounded-full">
                      <img
                        className=" w-full h-full rounded-full"
                        src="https://d2gwgwt9a7yxle.cloudfront.net/what_is_user_id_in_net_banking_mobile_871b681e52.jpg"
                      />
                    </div>
                    <span className=" font-Roboto text-sm ">Rahul</span>
                  </div>
                  <div className=" flex gap-4 justify-end">
                    <div className=" flex items-center gap-1 text-gray-500 text-[14px]">
                      <FaThumbsUp />
                      <span>34</span>
                    </div>
                    <div className=" flex items-center gap-1 text-gray-500 text-[14px]">
                      <LuMessageCircleMore />
                      <span>34</span>
                    </div>
                  </div>
                  <div></div>
                </div>
              </div>
            </SwiperSlide>
            <SwiperSlide
              className=" bg-white p-4 border border-black/15
                  rounded-md"
            >
              <div className=" space-y-4">
                <div className="w-full h-60 rounded-md">
                  <img
                    className=" w-full h-full rounded-xl"
                    src="https://fsa2-assets.imgix.net/assets/laptop-coding-terminal.jpg?auto=compress%2Cformat&crop=focalpoint&domain=fsa2-assets.imgix.net&fit=crop&fp-x=0.5&fp-y=0.5&h=558&ixlib=php-3.3.0&w=992"
                  />
                </div>
                <h2 className=" font-medium font-RobotoFlex text-sm">
                  Meet The Mentors : How I Find My Way into Coding
                </h2>
                <div className=" grid grid-cols-2 justify-between ">
                  <div className="flex gap-2 items-center">
                    <div className="w-6 h-6 rounded-full">
                      <img
                        className=" w-full h-full rounded-full"
                        src="https://d2gwgwt9a7yxle.cloudfront.net/what_is_user_id_in_net_banking_mobile_871b681e52.jpg"
                      />
                    </div>
                    <span className=" font-Roboto text-sm ">Rahul</span>
                  </div>
                  <div className=" flex gap-4 justify-end">
                    <div className=" flex items-center gap-1 text-gray-500 text-[14px]">
                      <FaThumbsUp />
                      <span>34</span>
                    </div>
                    <div className=" flex items-center gap-1 text-gray-500 text-[14px]">
                      <LuMessageCircleMore />
                      <span>34</span>
                    </div>
                  </div>
                  <div></div>
                </div>
              </div>
            </SwiperSlide>
          </Swiper>
        </div>

        <div className=" space-y-5 bg-gray-50 p-5 shadow">
          <h2 className="text-xl font-medium font-Roboto">Releated Posts</h2>
          <div className="grid grid-cols-4 gap-4">
            <div className=" space-y-2 bg-white p-3 shadow rounded-md">
              <img src="https://fsa2-assets.imgix.net/assets/laptop-coding-terminal.jpg?auto=compress%2Cformat&crop=focalpoint&domain=fsa2-assets.imgix.net&fit=crop&fp-x=0.5&fp-y=0.5&h=558&ixlib=php-3.3.0&w=992" />
              <div className="  flex flex-col gap-1">
                <h2 className=" font-medium font-RobotoFlex text-sm">
                  Meet The Mentors : How I Find My Way into Coding
                </h2>
                <p className="font-Inter font-light text-xs">
                  There are more online learning platforms available than ever.
                  Let's talk about how to choose one, and the best 13 options.
                </p>
                <div className=" flex gap-1 items-center ">
                  <LuFileSpreadsheet />
                  <span className=" font-medium text-sm font-Roboto">
                    Read more
                  </span>
                </div>
              </div>
            </div>
            <div className=" space-y-2 bg-white p-3 shadow rounded-md">
              <img src="https://fsa2-assets.imgix.net/assets/laptop-coding-terminal.jpg?auto=compress%2Cformat&crop=focalpoint&domain=fsa2-assets.imgix.net&fit=crop&fp-x=0.5&fp-y=0.5&h=558&ixlib=php-3.3.0&w=992" />
              <div className="  flex flex-col gap-1">
                <h2 className=" font-medium font-RobotoFlex text-sm">
                  Meet The Mentors : How I Find My Way into Coding
                </h2>
                <p className="font-Inter font-light text-xs">
                  There are more online learning platforms available than ever.
                  Let's talk about how to choose one, and the best 13 options.
                </p>
                <div className=" flex gap-1 items-center ">
                  <LuFileSpreadsheet />
                  <span className=" font-medium text-sm font-Roboto">
                    Read more
                  </span>
                </div>
              </div>
            </div>
            <div className=" space-y-2 bg-white p-3 shadow rounded-md">
              <img src="https://fsa2-assets.imgix.net/assets/laptop-coding-terminal.jpg?auto=compress%2Cformat&crop=focalpoint&domain=fsa2-assets.imgix.net&fit=crop&fp-x=0.5&fp-y=0.5&h=558&ixlib=php-3.3.0&w=992" />
              <div className="  flex flex-col gap-1">
                <h2 className=" font-medium font-RobotoFlex text-sm">
                  Meet The Mentors : How I Find My Way into Coding
                </h2>
                <p className="font-Inter font-light text-xs">
                  There are more online learning platforms available than ever.
                  Let's talk about how to choose one, and the best 13 options.
                </p>
                <div className=" flex gap-1 items-center ">
                  <LuFileSpreadsheet />
                  <span className=" font-medium text-sm font-Roboto">
                    Read more
                  </span>
                </div>
              </div>
            </div>
            <div className=" space-y-2 bg-white p-3 shadow rounded-md">
              <img src="https://fsa2-assets.imgix.net/assets/laptop-coding-terminal.jpg?auto=compress%2Cformat&crop=focalpoint&domain=fsa2-assets.imgix.net&fit=crop&fp-x=0.5&fp-y=0.5&h=558&ixlib=php-3.3.0&w=992" />
              <div className="  flex flex-col gap-1">
                <h2 className=" font-medium font-RobotoFlex text-sm">
                  Meet The Mentors : How I Find My Way into Coding
                </h2>
                <p className="font-Inter font-light text-xs">
                  There are more online learning platforms available than ever.
                  Let's talk about how to choose one, and the best 13 options.
                </p>
                <div className=" flex gap-1 items-center ">
                  <LuFileSpreadsheet />
                  <span className=" font-medium text-sm font-Roboto">
                    Read more
                  </span>
                </div>
              </div>
            </div>
            <div className=" space-y-2 bg-white p-3 shadow rounded-md">
              <img src="https://fsa2-assets.imgix.net/assets/laptop-coding-terminal.jpg?auto=compress%2Cformat&crop=focalpoint&domain=fsa2-assets.imgix.net&fit=crop&fp-x=0.5&fp-y=0.5&h=558&ixlib=php-3.3.0&w=992" />
              <div className="  flex flex-col gap-1">
                <h2 className=" font-medium font-RobotoFlex text-sm">
                  Meet The Mentors : How I Find My Way into Coding
                </h2>
                <p className="font-Inter font-light text-xs">
                  There are more online learning platforms available than ever.
                  Let's talk about how to choose one, and the best 13 options.
                </p>
                <div className=" flex gap-1 items-center ">
                  <LuFileSpreadsheet />
                  <span className=" font-medium text-sm font-Roboto">
                    Read more
                  </span>
                </div>
              </div>
            </div>
            <div className=" space-y-2 bg-white p-3 shadow rounded-md">
              <img src="https://fsa2-assets.imgix.net/assets/laptop-coding-terminal.jpg?auto=compress%2Cformat&crop=focalpoint&domain=fsa2-assets.imgix.net&fit=crop&fp-x=0.5&fp-y=0.5&h=558&ixlib=php-3.3.0&w=992" />
              <div className="  flex flex-col gap-1">
                <h2 className=" font-medium font-RobotoFlex text-sm">
                  Meet The Mentors : How I Find My Way into Coding
                </h2>
                <p className="font-Inter font-light text-xs">
                  There are more online learning platforms available than ever.
                  Let's talk about how to choose one, and the best 13 options.
                </p>
                <div className=" flex gap-1 items-center text-orange-500">
                  <LuFileSpreadsheet />
                  <span className=" font-medium text-sm font-Roboto">
                    Read more
                  </span>
                </div>
              </div>
            </div>
            <div className=" space-y-2 bg-white p-3 shadow rounded-md">
              <img src="https://fsa2-assets.imgix.net/assets/laptop-coding-terminal.jpg?auto=compress%2Cformat&crop=focalpoint&domain=fsa2-assets.imgix.net&fit=crop&fp-x=0.5&fp-y=0.5&h=558&ixlib=php-3.3.0&w=992" />
              <div className="  flex flex-col gap-1">
                <h2 className=" font-medium font-RobotoFlex text-sm">
                  Meet The Mentors : How I Find My Way into Coding
                </h2>
                <p className="font-Inter font-light text-xs">
                  There are more online learning platforms available than ever.
                  Let's talk about how to choose one, and the best 13 options.
                </p>
                <div className=" flex gap-1 items-center text-orange-500">
                  <LuFileSpreadsheet />
                  <span className=" font-medium text-sm font-Roboto">
                    Read more
                  </span>
                </div>
              </div>
            </div>
            <div className=" space-y-2 bg-white p-3 shadow rounded-md">
              <img src="https://fsa2-assets.imgix.net/assets/laptop-coding-terminal.jpg?auto=compress%2Cformat&crop=focalpoint&domain=fsa2-assets.imgix.net&fit=crop&fp-x=0.5&fp-y=0.5&h=558&ixlib=php-3.3.0&w=992" />
              <div className="  flex flex-col gap-1">
                <h2 className=" font-medium font-RobotoFlex text-sm">
                  Meet The Mentors : How I Find My Way into Coding
                </h2>
                <p className="font-Inter font-light text-xs">
                  There are more online learning platforms available than ever.
                  Let's talk about how to choose one, and the best 13 options.
                </p>
                <div className=" flex gap-1 items-center text-orange-500">
                  <LuFileSpreadsheet />
                  <span className=" font-medium text-sm font-Roboto">
                    Read more
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    
    </>
  );
};

export default CategoryResults;
