import React from 'react'
import { Outlet } from 'react-router-dom'

const Mainpage = () => {
  return (
    <>
     <Outlet/>
    </>
  )
}

export default Mainpage
