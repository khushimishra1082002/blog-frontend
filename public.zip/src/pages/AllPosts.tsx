import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { RootState, AppDispatch } from "../Redux Toolkit/Store";
import { fetchAllPosts } from "../Redux Toolkit/slice/PostSlice";
import { FaThumbsUp, FaThumbsDown } from "react-icons/fa6";
import { LuMessageCircleMore } from "react-icons/lu";
import { LuFileSpreadsheet } from "react-icons/lu";
import { Link } from "react-router-dom";
import {
  AiOutlineLike,
  AiFillLike,
  AiOutlineDislike,
  AiFillDislike,
} from "react-icons/ai";
import LikeDislikeComment from "./LikeDislikeComment";
import { authenticate } from "../../../Backend/middlewares/authMiddleware";
import { jwtDecode } from "jwt-decode";

const AllPosts = () => {
  const dispatch = useDispatch<AppDispatch>();

  const { posts, loading, error } = useSelector(
    (state: RootState) => state.postsData
  );
  console.log(posts);

  useEffect(() => {
    dispatch(fetchAllPosts());
  }, [dispatch]);

  if (loading) return <h2>Loading...</h2>;
  if (error) return <h2>Error: {error}</h2>;

  const token = localStorage.getItem("token");

  let userId: string | null = null;

  if (token) {
    try {
      interface DecodedTokenType {
        id: string;
        role: string;
        iat: number;
        exp: number;
      }

      const decodedToken: DecodedTokenType = jwtDecode(token);
      userId = decodedToken?.id;
      console.log("User Id from Token =>", userId);
    } catch (error) {
      console.error("Invalid Token", error);
    }
  }

  return (
    <>
      <div className="bg-white p-5 space-y-4">
        <h1 className=" text-xl font-semibold font-Roboto">All Posts</h1>
        <div className=" grid grid-cols-4 gap-2 gap-y-3">
          {posts.length > 0 ? (
            posts.slice(0, 16).map((post: any) => {
              const formattedDate = new Date(post.createdAt).toLocaleDateString(
                "en-GB",
                {
                  day: "numeric",
                  month: "long",
                  year: "numeric",
                }
              );

              return (
                <div>
                  <div
                    key={post._id}
                    className="shadow-lg bg-white rounded-md flex flex-col gap-4 p-5
                  border border-black/5
                     "
                  >
                    <span className=" font-Roboto text-gray-700 font-mdium text-sm">
                      {formattedDate}
                    </span>

                    <Link to={`singleBlogPage/${post._id}`}>
                      <h4
                        className=" text-xl font-Roboto font-medium hover:underline
                   line-clamp-2"
                      >
                        {post.title}
                      </h4>
                    </Link>
                    <p className="font-Inter text-[12px] font-light text-gray-800 line-clamp-4">
                      {post.content}
                    </p>

                    <div className="w-full h-56 overflow-hidden">
                      <img
                        className="w-full h-full shadow-lg object-cover
                   transition-transform duration-300 ease-in-out hover:scale-110"
                        src={post.image}
                        alt={post.title}
                      />
                    </div>

                    <div className=" grid grid-cols-2 justify-between pt-2 ">
                      <div className="flex gap-2 items-center">
                        <div className="w-6 h-6 rounded-full">
                          <img
                            className=" w-full h-full rounded-full"
                            src="https://d2gwgwt9a7yxle.cloudfront.net/what_is_user_id_in_net_banking_mobile_871b681e52.jpg"
                            alt="user avatar"
                          />
                        </div>
                        <span className=" font-Roboto text-sm ">
                          {post.author.name}
                        </span>
                      </div>

                      {/* Like Dislike Comment */}
                      <LikeDislikeComment
                        postId={post._id}
                        likes={post.likes}
                        dislikes={post.dislikes} 
                        currentUserId={userId}
                        
                      />
                    </div>
                  </div>
                </div>
              );
            })
          ) : (
            <p>No Posts Found</p>
          )}
        </div>
        <div className="flex justify-center w-full m-auto  pt-4">
          <button
            className="px-6 py-2 border border-black text-black
             font-medium rounded-full hover:bg-black hover:text-white duration-300"
          >
            View More
          </button>
        </div>
      </div>
    </>
  );
};

export default AllPosts;
