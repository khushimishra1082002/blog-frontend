import React from "react";
import Header from "../components/Header";
import Footer from "../components/Footer";
import Categories from "./Categories";
import AllPosts from "./AllPosts";
import PopularPost from "./PopularPost";
import TopPosts from "./TopPosts";
import FeaturedPosts from "./FeaturedPosts";
import RecommendedPost from "./RecommendedPost";
import TrendingPost from "./TrendingPost";
import SimilorPost from "./SimilorPost";
import RecentPost from "./RecentPost";

const Homepage = () => {
  return (
    <>
      <div className="space-y-1">
        <div className="sticky top-0 left-0 w-full z-50 bg-white ">
          <Header />
          <Categories />
        </div>
         <AllPosts />
        <PopularPost />
        <FeaturedPosts />
        <TopPosts />
        <RecommendedPost />
        <TrendingPost />
        <RecentPost/>
      
      
        <Footer />
      </div>
    </>
  );
};

export default Homepage;
