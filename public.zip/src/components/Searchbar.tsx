import React from 'react'

const Searchbar = () => {
  return (
    <>
      <div>
        <input type='text' placeholder='Search here'
         className=' border border-black/10 w-96 rounded-md'/>
      </div>
    </>
  )
}

export default Searchbar
