import React from 'react'

const BlogCard = () => {
  return (
    <>
      <div>
        Blog card
      </div>
    </>
  )
}

export default BlogCard
