import React from "react";
import { FaThumbsUp } from "react-icons/fa6";
import { LuMessageCircleMore } from "react-icons/lu";

const PostCardFive = ({ post }) => {
  return (
    <div className="bg-white p-4 shadow-lg rounded space-y-3">
      <div className="w-full h-60">
        <img
          className="w-full h-full object-cover"
          src={post.image}
          alt={post.title}
        />
      </div>

      <div className="space-y-4">
        <span className="font-Roboto text-gray-600 text-sm">
          {new Date(post.createdAt).toDateString()}
        </span>

        <h2 className="text-base font-Inter font-medium hover:underline line-clamp-2">
          {post.title}
        </h2>

        <p className="font-Inter text-[12px] font-light line-clamp-3">
          {post.content}
        </p>

        <div className="grid grid-cols-2 justify-between pt-2">
          <div className="flex gap-2 items-center">
            <div className="w-6 h-6 rounded-full">
              <img
                className="w-full h-full rounded-full shadow-lg"
                src="https://d2gwgwt9a7yxle.cloudfront.net/what_is_user_id_in_net_banking_mobile_871b681e52.jpg"
                alt="author"
              />
            </div>
            <span className="font-Roboto text-sm">Author</span>
          </div>

          <div className="flex gap-4 justify-end">
            <div className="flex items-center gap-1 text-gray-500 text-[14px]">
              <FaThumbsUp />
              <span>{post.likes.length}</span>
            </div>

            <div className="flex items-center gap-1 text-gray-500 text-[14px]">
              <LuMessageCircleMore />
              <span>{post.comments.length}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PostCardFive;
