import React from 'react'

const BlogList = () => {
  return (
    <>
      <div>
        Blog list
      </div>
    </>
  )
}

export default BlogList
