import React from "react";
import { LuFileSpreadsheet } from "react-icons/lu";
import { FaThumbsUp, FaThumbsDown } from "react-icons/fa6";
import { LuMessageCircleMore } from "react-icons/lu";

const PostCardThree = ({ post }) => {
  return (
    <>
      <div
        className=" grid grid-cols-2 gap-5 shadow bg-white   p-5
       border border-black/5"
      >
        <div className="w-full h-full">
          <img
            className="w-full h-full object-cover shadow rounded"
            src={post.image}
          />
        </div>
        <div className=" flex flex-col gap-3">
          <span className=" text-cyan-500 font-semibold text-[12px] font-Inter tracking-wider">
            {post.category}
          </span>
          <h3
            className=" text-base font-RobotoFlex hover:underline"
          >
            {post.title}
          </h3>
          <span className=" font-Roboto text-gray-400 font-mdium text-sm">
            April 22 , 2025
          </span>
          <p className=" text-[11px]  font-Inter font-light line-clamp-4">
            {post.content}
          </p>
          <div className=" grid grid-cols-2 justify-between ">
            <div className="flex gap-2 items-center">
              <div className="w-6 h-6 rounded-full">
                <img
                  className=" w-full h-full rounded-full"
                  src="https://d2gwgwt9a7yxle.cloudfront.net/what_is_user_id_in_net_banking_mobile_871b681e52.jpg"
                />
              </div>
              <span className=" font-Roboto text-sm ">Rahul Verma</span>
            </div>
            <div className=" flex gap-4 justify-end">
              <div className=" flex items-center gap-1 text-gray-500 text-[14px]">
                <FaThumbsUp />
                <span>34</span>
              </div>
              <div className=" flex items-center gap-1 text-gray-500 text-[14px]">
                <LuMessageCircleMore />
                <span>34</span>
              </div>
            </div>
            <div></div>
          </div>
          <div className=" flex gap-1 items-center ">
            <span className=" font-medium text-xs font-Roboto text-orange-600">
              Read more
            </span>
          </div>
        </div>
      </div>
    </>
  );
};

export default PostCardThree;
