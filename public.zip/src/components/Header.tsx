import React from "react";
import Searchbar from "./Searchbar";

const Header = () => {
  return (
    <>
      <div className="w-full h-16 bg-white flex items-center shadow sticky top-0">
        <div className="w-11/12 mx-auto flex justify-between items-center">
          <div>
            <img
              className="w-24"
              src="https://logodix.com/logo/34884.jpg"
              alt="logo"
            />
          </div>
          <div>
              <Searchbar/>
            </div>
          <div className=" flex gap-4 items-center">
            <ul className=" flex gap-4 font-RobotoFlex font-medim">
              <li>Home</li>
              <li>About</li>
              <li>Contact</li>
              <li>New Blog</li>
            </ul>
           
            <div className="flex gap-2">
              <button
                className="bg-skin-accent_one text-white px-4 py-2 text-center
                text-base font-Roboto hover:scale-105 shadow hover:shadow duration-300 rounded-sm"
              >
                Register
              </button>
              <button
                className="bg-transparent  px-4 py-2 text-center
               text-base font-Roboto hover:scale-105 shadow hover:shadow duration-300 rounded-sm"
              >
                Login
              </button>
            </div>
            <div>
                <img className="w-10 h-10 rounded-full"
                 src="https://d2gwgwt9a7yxle.cloudfront.net/what_is_user_id_in_net_banking_mobile_871b681e52.jpg"/>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Header;
