import React from 'react'

const Footer = () => {
  return (
    <>
      <div className=' bg-white h-96 w-full py-8 shadow space-y-5'>
      <div className=' w-11/12 m-auto space-y-8'>
      <div className='flex justify-between items-center '>
        <div className=' space-y-2'>
          <h3 className=' text-xl font-Poppins font-medium'>Sign Up To Our Newsletter</h3>
          <p className='font-Inter text-sm text-gray-600'>
            Stay Up To Date with the Latest News,announcements and Articles
          </p>
        </div>
        <div className=' space-x-1'>
          <input type=' text' placeholder='Enter your email' className='w-80 border border-black/10
          rounded-md text-sm p-2'/>
          <button className='bg-gray-950 text-white font-Inter
          rounded-sm hover:scale-105 duration-500 text-sm p-2'>Subscribe</button>
        </div>
       </div>
       <div className=' grid grid-cols-7'>
        <div className='col-span-2 space-y-2'>
         <h4 className=' text-base font-medium font-Poppins'>Blogs Website</h4>
         <p className='font-Inter text-xs text-gray-600 w-11/12'>
            Stay Up To Date with the Latest News,announcements and Articles
          </p>
        </div>
        <div className=' space-y-2'>
        <h4 className=' text-base font-medium font-Poppins'>Product</h4>
        <ul className=' space-y-2'>
          <li className='text-xs font-Inter'>Overviw</li>
          <li className='text-xs font-Inter'>Features</li>
          <li className='text-xs font-Inter'>Solutions</li>
          <li className='text-xs font-Inter'>Tutorials</li>
          <li className='text-xs font-Inter'>Pricing</li>
          <li className='text-xs font-Inter'>Release</li>
        </ul>
        </div>
        <div className=' space-y-2'>
        <h4 className=' text-base font-medium font-Poppins'>Social</h4>
        <ul className=' space-y-2'>
          <li className='text-xs font-Inter'>Twitter</li>
          <li className='text-xs font-Inter'>Facebook</li>
          <li className='text-xs font-Inter'>Instagram</li>
          <li className='text-xs font-Inter'>Linkdin</li>
          <li className='text-xs font-Inter'>Dribble</li>
          <li className='text-xs font-Inter'>Github</li>
        </ul>
        </div>
        <div className=' space-y-2'>
        <h4 className=' text-base font-medium font-Poppins'>Company</h4>
        <ul className=' space-y-2'>
          <li className='text-xs font-Inter'>Overviw</li>
          <li className='text-xs font-Inter'>Features</li>
          <li className='text-xs font-Inter'>Solutions</li>
          <li className='text-xs font-Inter'>Tutorials</li>
          <li className='text-xs font-Inter'>Pricing</li>
          <li className='text-xs font-Inter'>Release</li>
        </ul>
        </div>
        <div className=' space-y-2'>
        <h4 className=' text-base font-medium font-Poppins'>Resources</h4>
        <ul className=' space-y-2'>
          <li className='text-xs font-Inter'>Overviw</li>
          <li className='text-xs font-Inter'>Features</li>
          <li className='text-xs font-Inter'>Solutions</li>
          <li className='text-xs font-Inter'>Tutorials</li>
          <li className='text-xs font-Inter'>Pricing</li>
          <li className='text-xs font-Inter'>Release</li>
        </ul>
        </div>
        <div className=' space-y-2'>
        <h4 className=' text-base font-medium font-Poppins'>Legal</h4>
        <ul className=' space-y-2'>
          <li className='text-xs font-Inter'>Terms</li>
          <li className='text-xs font-Inter'>Privacy</li>
          <li className='text-xs font-Inter'>Cookies</li>
          <li className='text-xs font-Inter'>License</li>
          <li className='text-xs font-Inter'>Setting</li>
          <li className='text-xs font-Inter'>Contact</li>
        </ul>
        </div>
       </div>
      </div>
      </div>
    </>
  )
}

export default Footer
