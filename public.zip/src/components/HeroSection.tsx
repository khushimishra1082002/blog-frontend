import React from 'react'

const HeroSection = () => {
  return (
    <>
     <div>
      Hero Section
     </div>
    </>
  )
}

export default HeroSection
