const conf = {
  RegisterUrl: String(import.meta.env.VITE_REGISTER_URL),
  LoginUrl: String(import.meta.env.VITE_LOGIN_URL),
  
};

export default conf;
