import { configureStore } from '@reduxjs/toolkit';
import postReducer from "./slice/PostSlice"

export const store = configureStore({
  reducer: {
   postsData : postReducer
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;