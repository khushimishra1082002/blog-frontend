import React from "react";
import { Routes, Route } from "react-router-dom";
import Mainpage from "./pages/Mainpage";
import Homepage from "./pages/Homepage";
import LoggedInPage from "./pages/LoggedInPage";
import Profile from "./pages/Profile";
import CategoryResults from "./pages/CategoryResults";
import SinglePost from "./pages/SinglePost";

const App = () => {
  return (
    <>
      <Routes>
        <Route path="/" element={<Mainpage />}>
          <Route path="home" element={<Homepage />} />
          <Route index element={<Homepage />} />
          <Route path="LoggedInPage" element={<LoggedInPage />} />
          <Route path="profilePage" element={<Profile />} />
          <Route path="singleBlogPage/:id" element={<SinglePost />} />
          <Route path="CategoryResults" element={<CategoryResults />} />
        </Route>
      </Routes>
    </>
  );
};

export default App;
